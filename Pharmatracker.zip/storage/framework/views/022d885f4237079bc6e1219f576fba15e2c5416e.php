

<?php $__env->startSection('content'); ?>

<section class="content">
    <div class="container-fluid">
        <h2 class="text-center display-4">Pill Finder</h2>
              <div class="">   
                  <div class="col-md-6 offset-md-1 ">
                        <div class="form-group">  
                             <!-- Direct to Web.php and call controller-->    
                            <form action="/search" class="ali"> 
                            <div class="input-group  input-group-lg">
                                <input type="text" name="query" class="form-control" placeholder="Search name">
                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-lg btn-default">
                                        <i class="fa fa-search"></i>
                                    </button>
                                    <button class="btn-lg btn-info" href="userpage.drugs">
                                    <i class="fa fa-refresh"></i> </button>
                                             
                            </div>
                    </div>
                        </div>
                      </form>
                      
                  </div>
                 
              </div>
        
     
        <div class="row ali">
          <div class="col-md-12">
              <div class="">
                  <table id="example" class="table table-striped">
                      <thead>
                          <tr>
                              <th>Name</th>
                              <th>Type</th>
                              <th>Description</th>                         
                          </tr>
                      </thead>  
                      <tbody>    
                         <!-- Data table for list of drugs to display data-->                
                        <?php $__currentLoopData = $drugs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td hidden class="id"><?php echo e($items->id); ?></td>
                        <td> <?php echo e($items->name); ?></td>
                        <td> <?php echo e($items->type_drugs); ?></td>              
                        <td> <?php echo e($items->description); ?></td>            
                            </tr>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
                </tbody>                
                  </table>
              </div>
              <nav aria-label="Page navigation example">
                <ul class="pagination justify-content-end">
                  <li class="page-item disabled">       
                  </li>
                   <!-- pagination number--> 
                  <li>   <?php echo e(($drugs->links())); ?></li>
                  </li>
                </ul>
              </nav>
          </div>
      </div>
    </form>
</div>
     
    

    </div>
</section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


<script type="text/javascript">

      $("#nameid").select2({
            placeholder: "Select a Name",
            allowClear: true
        });
</script>

        












<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.remind', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Pharmatracker\resources\views/userpage/drugs.blade.php ENDPATH**/ ?>